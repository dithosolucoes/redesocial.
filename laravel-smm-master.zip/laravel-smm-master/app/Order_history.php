<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_history extends Model
{
    //
}
